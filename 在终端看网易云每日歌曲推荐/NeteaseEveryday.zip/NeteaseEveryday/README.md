# Introduction
preparing

# Usage
```
usage: NeteaseEveryday.py [-h] --username USERNAME --password PASSWORD

在终端看网易云每日歌曲推荐

optional arguments:
  -h, --help           show this help message and exit
  --username USERNAME  用户名
  --password PASSWORD  密码
```