# Introduction
preparing

# Usage
```
usage: ClearQzone.py [-h] [--manual]

批量删除QQ空间说说

optional arguments:
  -h, --help  show this help message and exit
  --manual    每条说说删除前是否需要手动确认
```