# Introduction


# Usage
```
usage: NeteaseListenLeaderboard.py [-h] --username USERNAME --password
                                   PASSWORD

爬取目标用户的网易云听歌排行榜

optional arguments:
  -h, --help           show this help message and exit
  --username USERNAME  用户名
  --password PASSWORD  密码
```