# Introduction


# Usage
```
usage: delallweibos.py [-h] --username USERNAME --password PASSWORD

批量删除自己所有的微博

optional arguments:
  -h, --help           show this help message and exit
  --username USERNAME  用户名
  --password PASSWORD  密码
```