# Introduction


# Usage
```
usage: weiboEmoji.py [-h] --username USERNAME --password PASSWORD

下载指定微博用户发的所有图片

optional arguments:
  -h, --help           show this help message and exit
  --username USERNAME  用户名
  --password PASSWORD  密码
```