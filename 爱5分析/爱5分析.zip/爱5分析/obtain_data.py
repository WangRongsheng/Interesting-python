from bs4 import BeautifulSoup
import pandas as pd 
import requests

url = "http://comment.bilibili.com/123519261.xml"
html = requests.get(url)
html.encoding = "utf8"

soup = BeautifulSoup(html.text, "lxml")
results = soup.find_all("d")

comments = [comment.text for comment in results]
comments_dict = {"comments": comments}

df = pd.DataFrame(comments_dict)
df.to_csv("bilibili_data.csv", encoding="utf-8-sig")

print("爬取完成！")
