# Introduction


# Usage
```
usage: WeiboSender.py [-h] --username USERNAME --password PASSWORD

大吼一声发条微博

optional arguments:
  -h, --help           show this help message and exit
  --username USERNAME  用户名
  --password PASSWORD  密码
```