# Introduction


# Usage
#### Spider
```
python jdgoods.py
```
#### Visualization
```sh
python analysis.py
```