# Introduction
https://mp.weixin.qq.com/s/NhK9eeWNXv_wPnolccRR-g

# Usage
#### Spider
```
python tbgoods.py
```
#### Visualization
```sh
python analysis.py
```