# Introduction
https://mp.weixin.qq.com/s/_82U7luG6jmV-xb8-Qkiew

# Usage
```
usage: NeteaseSongListDownloader.py [-h] --username USERNAME --password
                                    PASSWORD

下载网易云音乐登录用户创建/收藏的歌单内所有歌曲

optional arguments:
  -h, --help           show this help message and exit
  --username USERNAME  用户名
  --password PASSWORD  密码
```