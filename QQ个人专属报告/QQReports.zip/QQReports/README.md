# Introduction
https://mp.weixin.qq.com/s/dsVtEp_TFeyeSAAUn1zFEw

# Usage
```sh
python generate.py
```

# Results
![img](./results/personal_info.jpg)  
![img](./results/friends_info.jpg)  
![img](./results/recent_operation_info.jpg)