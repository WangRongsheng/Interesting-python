# Introduction


# Usage
```
usage: signin.py [-h] --username USERNAME --password PASSWORD

网易云音乐自动签到

optional arguments:
  -h, --help           show this help message and exit
  --username USERNAME  用户名
  --password PASSWORD  密码
```

# Noted
```
When config.json exists, --username and --password are useless.
So, you should modify/delete it firstly if the username is different from what the config.json contains.
```